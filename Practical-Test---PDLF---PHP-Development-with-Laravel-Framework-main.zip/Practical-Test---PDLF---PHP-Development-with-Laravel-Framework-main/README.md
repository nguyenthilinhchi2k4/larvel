<img src="https://github.com/LINHTRAN9x/Practical-Test---PDLF---PHP-Development-with-Laravel-Framework/assets/133183567/68288ea8-50f6-46c8-9ae1-7cdb41e7b178">
